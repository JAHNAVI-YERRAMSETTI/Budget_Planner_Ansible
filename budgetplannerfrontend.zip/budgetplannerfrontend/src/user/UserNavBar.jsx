import React from 'react'

const UserNavBar = () => {
  return (
    <div>
      
    </div>
  )
}

export default UserNavBar
