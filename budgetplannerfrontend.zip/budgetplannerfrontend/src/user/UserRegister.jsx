import React from 'react'

const UserRegister = () => {
  return (
    <div>
      
    </div>
  )
}

export default UserRegister
