import React from 'react'

const Notifications = () => {
  return (
    <div>
      
    </div>
  )
}

export default Notifications
