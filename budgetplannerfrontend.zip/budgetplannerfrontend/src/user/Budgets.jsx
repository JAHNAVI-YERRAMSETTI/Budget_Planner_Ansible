import React from 'react'

const Budgets = () => {
  return (
    <div>
      
    </div>
  )
}

export default Budgets
