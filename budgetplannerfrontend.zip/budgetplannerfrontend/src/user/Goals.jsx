import React from 'react'

const Goals = () => {
  return (
    <div>
      
    </div>
  )
}

export default Goals
