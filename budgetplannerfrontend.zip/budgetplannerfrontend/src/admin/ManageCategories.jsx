import React from 'react'

const ManageCategories = () => {
  return (
    <div>
      
    </div>
  )
}

export default ManageCategories
