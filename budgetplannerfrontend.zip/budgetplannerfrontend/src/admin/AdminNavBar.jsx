import React from 'react'

const AdminNavBar = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminNavBar
