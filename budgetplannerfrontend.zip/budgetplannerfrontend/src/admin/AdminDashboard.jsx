import React from 'react'

const AdminDashboard = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default AdminDashboard
