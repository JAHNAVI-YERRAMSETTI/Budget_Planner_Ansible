import React from 'react'

const MainNavBar = () => {
  return (
    <div>
      
    </div>
  )
}

export default MainNavBar
